export default function Root({ children }) {
  return (
    <html>
      <body className="bg-black text-white">{children}</body>
    </html>
  );
}