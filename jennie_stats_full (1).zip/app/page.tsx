export default function Home() {
  return (
    <div className="text-center py-20 text-red-500 text-4xl">
      Jennie Stats – Homepage Working
    </div>
  );
}