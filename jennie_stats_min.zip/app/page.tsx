export default function Home() {
  return (
    <div>
      <h1 className="text-red-500 text-4xl font-bold">Jennie Stats</h1>
      <p>Minimal starter to verify deployment works.</p>
    </div>
  );
}