export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-black text-white p-10">
        {children}
      </body>
    </html>
  );
}