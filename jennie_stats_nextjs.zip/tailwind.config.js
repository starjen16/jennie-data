module.exports={
  content:["./app/**/*.{js,ts,jsx,tsx}"],
  theme:{ extend:{ colors:{ ruby:'#ff0033'} } },
  plugins:[]
};