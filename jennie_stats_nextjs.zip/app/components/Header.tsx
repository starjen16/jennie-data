'use client';
import Link from 'next/link';

export default function Header(){
  return (
    <header className="w-full py-4 border-b border-ruby mb-6">
      <div className="max-w-6xl mx-auto flex justify-between px-4">
        <Link href="/" className="text-3xl font-bold text-ruby">Jennie</Link>
        <nav className="flex gap-6">
          <Link href="/spotify">Spotify</Link>
          <Link href="/youtube">YouTube</Link>
        </nav>
      </div>
    </header>
  );
}
