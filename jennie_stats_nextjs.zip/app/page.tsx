export default function Home(){
  return (
    <div>
      <h1 className="text-4xl text-ruby font-bold mb-4">Jennie Stats Dashboard</h1>
      <p className="text-lg">Welcome to the live stats hub.</p>
    </div>
  );
}
