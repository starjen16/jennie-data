export default function Spotify(){
  return <h1 className="text-3xl font-bold text-ruby">Spotify Data</h1>;
}
