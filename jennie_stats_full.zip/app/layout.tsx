
import './globals.css';
import Header from '../components/Header';

export const metadata={title:'Jennie Stats',description:'Jennie global stats dashboard'};

export default function RootLayout({children}:{children:React.ReactNode}){
 return(
 <html>
   <body className='bg-black text-white'>
     <Header/>
     {children}
   </body>
 </html>
 );
}
