export const metadata = { title: "Jennie Stats" };
export default function RootLayout({children}) {
  return (<html><body>{children}</body></html>);
}