export default function Home(){
  return (<div style={{padding:40}}><h1>Jennie Stats — Working Build</h1></div>);
}