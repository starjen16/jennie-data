
module.exports = {
 content: ['./app/**/*.{js,ts,jsx,tsx}','./components/**/*.{js,ts,jsx,tsx}'],
 theme: { extend: { colors:{ jred:'#ff3b3b'} } },
 plugins:[]
};
